# Plan de cierre técnico · ISM Developer v2.0

Objetivo: cerrar los hallazgos de prioridad alta, verificar el comportamiento real en producción y ejecutar una publicación controlada.

## Fase 0 · Línea base y respaldo
- Confirmar rama `main` limpia.
- Crear commit y etiqueta de respaldo antes del cierre.
- Mantener copia de la versión pública anterior.

## Fase 1 · SEO y rendimiento inmediato — COMPLETADA
- H-002: optimizar el logo horizontal reutilizado.
- H-004: crear y conectar la imagen Open Graph de 1200 × 630.
- H-006: agregar H1 estático de respaldo en portafolio.
- Medir nuevamente peso local y validar HTML/JavaScript.

## Fase 2 · Presupuesto de rendimiento — COMPLETADA
- H-003: inventariar recursos utilizados por página.
- Comprimir imágenes críticas y eliminar referencias no necesarias.
- Cargar diferido lo que queda fuera del primer viewport.
- Reducir dependencias y revisar Lucide.
- Ejecutar Lighthouse móvil y escritorio.

## Fase 3 · Seguridad y privacidad — COMPLETADA EN CÓDIGO
- H-007: crear `vercel.json` con encabezados de seguridad compatibles.
- Verificar CSP, HSTS, Referrer-Policy, Permissions-Policy y framing.
- H-008: crear política de privacidad/cookies.
- Cargar Analytics solo después del consentimiento cuando corresponda.
- Agregar gestión visible de preferencias.

## Fase 4 · Accesibilidad WCAG 2.2 AA
- H-012: recorrido completo con teclado.
- Foco visible y orden lógico.
- Contraste, zoom 200 %, formularios, diálogos y acordeones.
- Prueba NVDA en Windows y VoiceOver en Safari/iPhone cuando esté disponible.
- Registro de hallazgos y correcciones.

## Fase 5 · Compatibilidad
- H-013: matriz Edge, Chrome, Firefox y Safari.
- Escritorio: 1366 × 768 y 1920 × 1080.
- Móvil: 360 × 800, 390 × 844 y tablet 768 × 1024.
- Pruebas de navegación, efectos, FAQ, tarjetas, formulario, WhatsApp y portafolio.

## Fase 6 · Publicación controlada
- H-001: publicar `main` solo después de aprobar fases anteriores.
- Verificar producción, metadatos, headers, Analytics y enlaces.
- Monitorear 24–48 horas.
- Repetir evaluación integral y registrar nota final.

## Criterio de cierre
- Cero errores en `npm run check` y `npm run validate`.
- Sin hallazgos críticos o altos abiertos.
- Lighthouse sin oportunidades críticas y con métricas registradas.
- Pruebas de teclado y navegadores documentadas.
- Sitio público sincronizado con la versión aprobada.


## Avance registrado al 5 de agosto de 2026
- Fase 1 completada: logo, Open Graph, iconos PWA y H1 de respaldo.
- Fase 2 completada: portada reducida de 2,49 MB a 0,71 MB considerando HTML y recursos locales únicos.
- Reducción total aproximada: 71,3 %.
- Presupuesto automático incorporado mediante `npm run audit:performance`.
- Fase 3 completada en código: headers de Vercel, CSP con hash, política de privacidad, consentimiento y auditoría automática.
- Verificación de H-007 pendiente en producción mediante respuesta HTTP real.
- Próxima fase: accesibilidad WCAG 2.2 AA.
