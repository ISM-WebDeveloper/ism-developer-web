// POSICIÓN INICIAL Y NAVEGACIÓN INTERNA
// Todas las rutas del navbar apuntan a secciones reales de esta página y
// descuentan la altura del navbar para no ocultar los títulos.
if ("scrollRestoration" in history) {
  history.scrollRestoration = "manual";
}
const getSectionAnchorOffset = () => {
  const configuredOffset = Number.parseFloat(
    getComputedStyle(document.documentElement).getPropertyValue("--section-anchor-offset")
  );
  return Number.isFinite(configuredOffset) ? configuredOffset : 100;
};
const scrollToSection = (target, behavior = "smooth") => {
  const targetTop = target.id === "inicio"
    ? 0
    : target.getBoundingClientRect().top + window.scrollY - getSectionAnchorOffset();
  window.scrollTo({
    top: Math.max(0, Math.round(targetTop)),
    left: 0,
    behavior
  });
};
const restoreRequestedPosition = () => {
  const targetId = decodeURIComponent(window.location.hash.slice(1));
  const target = targetId ? document.getElementById(targetId) : null;
  requestAnimationFrame(() => {
    if (target) {
      scrollToSection(target, "auto");
      return;
    }
    if (!targetId) {
      window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    }
  });
};
if (document.readyState === "loading") {
  window.addEventListener("DOMContentLoaded", restoreRequestedPosition, { once: true });
} else {
  restoreRequestedPosition();
}
window.addEventListener("pageshow", restoreRequestedPosition);
// NAVBAR PREMIUM
const navbar = document.getElementById("navbar");
const navToggle = document.getElementById("navToggle");
const primaryNav = document.getElementById("primaryNav");
let navbarHideTimer;
const setNavigationOpen = (isOpen) => {
  if (!navbar || !navToggle) return;
  navbar.classList.toggle("menu-open", isOpen);
  navToggle.setAttribute("aria-expanded", String(isOpen));
  navToggle.setAttribute("aria-label", isOpen ? "Cerrar menú principal" : "Abrir menú principal");
  navToggle.innerHTML = `<i data-lucide="${isOpen ? "x" : "menu"}"></i>`;
  if (window.lucide) {
    lucide.createIcons();
  }
};
navToggle?.addEventListener("click", () => {
  setNavigationOpen(!navbar?.classList.contains("menu-open"));
});
primaryNav?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => setNavigationOpen(false));
});
document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener("click", (event) => {
    const href = link.getAttribute("href");
    if (!href || href === "#") return;
    const target = document.getElementById(decodeURIComponent(href.slice(1)));
    if (!target) return;
    event.preventDefault();
    setNavigationOpen(false);
    scrollToSection(target);
    if (window.location.hash !== href) {
      history.pushState(null, "", href);
    }
  });
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    setNavigationOpen(false);
  }
});
window.addEventListener("resize", () => {
  if (window.innerWidth > 1024) {
    setNavigationOpen(false);
  }
});
window.addEventListener("scroll", () => {
  if (!navbar) return;
  if (window.innerWidth <= 600) {
    navbar.classList.remove("scrolled");
    navbar.classList.remove("nav-hidden");
    clearTimeout(navbarHideTimer);
    return;
  }
  if (navbar.classList.contains("menu-open")) {
    navbar.classList.remove("nav-hidden");
    clearTimeout(navbarHideTimer);
    return;
  }
  if (window.scrollY > 60) {
    navbar.classList.add("scrolled");
    navbar.classList.remove("nav-hidden");
    clearTimeout(navbarHideTimer);
    navbarHideTimer = setTimeout(() => {
      navbar.classList.add("nav-hidden");
    }, 1500);
  } else {
    navbar.classList.remove("scrolled");
    navbar.classList.remove("nav-hidden");
    clearTimeout(navbarHideTimer);
  }
});
// REVEAL PREMIUM POR VIEWPORT
// Gestionado por assets/js/reveal-compat.js para ofrecer una entrada
// consistente en Edge, Chrome, Firefox, Safari y navegadores sin
// IntersectionObserver.
// ANIMACIÓN SOBRE MÍ
// Alterna el foco de los pins del visual izquierdo.
const aboutOrbit = document.querySelector(".about-orbit");
const aboutPins = document.querySelectorAll(".about-orbit-pin");
let aboutPinIndex = 0;
let aboutPinTimer;
const setAboutPin = (index) => {
  if (!aboutPins.length) return;
  aboutPins.forEach((pin) => pin.classList.remove("is-active"));
  aboutPinIndex = (index + aboutPins.length) % aboutPins.length;
  aboutPins[aboutPinIndex].classList.add("is-active");
};
if (aboutPins.length && !aboutOrbit?.classList.contains("image-test")) {
  const startAboutPinCycle = () => {
    clearInterval(aboutPinTimer);
    aboutPinTimer = setInterval(() => {
      setAboutPin(aboutPinIndex + 1);
    }, 3200);
  };
  startAboutPinCycle();
  aboutPins.forEach((pin, index) => {
    pin.addEventListener("mouseenter", () => {
      clearInterval(aboutPinTimer);
      setAboutPin(index);
    });
    pin.addEventListener("mouseleave", startAboutPinCycle);
    pin.addEventListener("focus", () => {
      clearInterval(aboutPinTimer);
      setAboutPin(index);
    });
    pin.addEventListener("blur", startAboutPinCycle);
  });
}
const portfolioSection = document.querySelector(".ism-portfolio-section");
if (portfolioSection) {
  const portfolioPanel = document.getElementById("portfolioPanel");
  const portfolioStatus = document.getElementById("portfolioSelectionStatus");
  const portfolioTabs = [...portfolioSection.querySelectorAll("[data-portfolio-tab]")];
  const portfolioDataNode = document.getElementById("ismPortfolioData");
  let portfolioData = { solutions: [], clients: [] };
  if (portfolioDataNode) {
    try {
      portfolioData = JSON.parse(portfolioDataNode.textContent || "{}");
    } catch (error) {
      console.error("No fue posible cargar el catálogo principal de soluciones.", error);
    }
  }
  const iconMarkup = (name) => `<i data-lucide="${name}" aria-hidden="true"></i>`;
  const renderGallery=(item) => {
    const [firstImage] = item.images;
    const renderMainImage = (image) => image.pending
      ? `<div class="ism-portfolio-image-placeholder" data-portfolio-main-placeholder>
          <i data-lucide="monitor" aria-hidden="true"></i>
          <strong>${image.label}</strong>
          <span>Espacio preparado para imagen real de interfaz</span>
       </div>`
      : `<img src="${image.src}" alt="${image.alt}" width="960" height="540" loading="lazy" decoding="async" data-portfolio-main-image>`;
    return `
      <div class="ism-portfolio-gallery">
        <div class="ism-portfolio-main-media" data-portfolio-main-media>
          ${renderMainImage(firstImage)}
          <span class="ism-portfolio-media-caption" data-portfolio-media-caption>${firstImage.label}</span>
        </div>
        <div class="ism-portfolio-thumbs" data-count="${item.images.length}" aria-label="Vistas disponibles de ${item.name}">
          ${item.images.map((image, index) => `
            <button class="ism-portfolio-thumb${image.pending ? " is-pending" : ""}${index === 0 ? " is-active" : ""}" type="button"
              aria-label="Mostrar ${image.label} de ${item.name}" aria-pressed="${index === 0}"
              data-portfolio-image-index="${index}">
              ${image.pending
                ? `<span class="ism-portfolio-thumb-placeholder"><i data-lucide="monitor" aria-hidden="true"></i><small>${image.label}</small></span>`
                : `<img src="${image.src}" alt="" width="240" height="135" loading="lazy" decoding="async">`}
            </button>
          `).join("")}
        </div>
      </div>
    `;
  };
  const renderDetail=(item) => `
    <div class="ism-portfolio-detail">
      ${renderGallery(item)}
      <div class="ism-portfolio-copy">
        <div class="ism-portfolio-copy-top">
          <span class="ism-portfolio-copy-type">${item.type}</span>
        </div>
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <div class="ism-portfolio-use-case"><strong>Puede ayudarte si:</strong> ${item.useCase}</div>
        <div class="ism-portfolio-stack">${item.stack}</div>
        <a class="ism-portfolio-detail-link" href="${item.link}"
          data-track-event="${item.type === "Solución ISM" ? "solution_quote_click" : "project_click"}"
          data-track-category="${item.type === "Solución ISM" ? "solutions" : "portfolio"}"
          data-track-label="${item.name}">
          ${item.ctaLabel || "Ver implementación"} <span aria-hidden="true">→</span>
        </a>
      </div>
    </div>
  `;
  const renderWorkbench = (items, selectedIndex, selectorLabel) => {
    const selectedItem = items[selectedIndex];
    return `
      <div class="ism-portfolio-workbench${items.length > 4 ? " is-tools" : ""}${selectorLabel === "Soluciones ISM" ? " is-solutions" : ""}">
        <div class="ism-portfolio-selector">
          <span class="ism-portfolio-selector-label">${selectorLabel}</span>
          ${items.map((item, index) => `
            <button class="ism-portfolio-item-button${index === selectedIndex ? " is-active" : ""}" type="button"
              aria-pressed="${index === selectedIndex}" data-portfolio-item-index="${index}">
              <span class="ism-portfolio-item-icon">${iconMarkup(item.icon)}</span>
              <span class="ism-portfolio-item-copy">
                <strong>${item.name}</strong>
                <small>${item.label}</small>
              </span>
            </button>
          `).join("")}
        </div>
        ${renderDetail(selectedItem)}
      </div>
    `;
  };
  const state = {
    tab: "solutions",
    selected: { clients: 0, solutions: 0 }
  };
  const syncLucide = () => {
    if (window.lucide?.createIcons) {
      window.lucide.createIcons();
    }
  };
  const updateGalleryImage = (item, imageIndex) => {
    if (!portfolioPanel) return;
    const image = item.images[imageIndex];
    const media = portfolioPanel.querySelector("[data-portfolio-main-media]");
    const caption = portfolioPanel.querySelector("[data-portfolio-media-caption]");
    if (!image || !media || !caption) return;
    media.classList.add("is-changing");
    window.setTimeout(() => {
      media.querySelector("[data-portfolio-main-image], [data-portfolio-main-placeholder]")?.remove();
      if (image.pending) {
        const placeholder = document.createElement("div");
        placeholder.className = "ism-portfolio-image-placeholder";
        placeholder.setAttribute("data-portfolio-main-placeholder", "");
        placeholder.innerHTML = `<i data-lucide="monitor" aria-hidden="true"></i><strong>${image.label}</strong><span>Espacio preparado para imagen real de interfaz</span>`;
        media.prepend(placeholder);
      } else {
        const nextImage = document.createElement("img");
        nextImage.src = image.src;
        nextImage.alt = image.alt;
        nextImage.width = 960;
        nextImage.height = 540;
        nextImage.loading = "lazy";
        nextImage.decoding = "async";
        nextImage.setAttribute("data-portfolio-main-image", "");
        media.prepend(nextImage);
      }
      caption.textContent = image.label;
      portfolioPanel.querySelectorAll("[data-portfolio-image-index]").forEach((button) => {
        const active = Number(button.dataset.portfolioImageIndex) === imageIndex;
        button.classList.toggle("is-active", active);
        button.setAttribute("aria-pressed", String(active));
      });
      media.classList.remove("is-changing");
      syncLucide();
    }, 120);
  };
  const bindPanelInteractions = () => {
    if (!portfolioPanel) return;
    const items = portfolioData[state.tab];
    portfolioPanel.querySelectorAll("[data-portfolio-item-index]").forEach((button) => {
      button.addEventListener("click", () => {
        state.selected[state.tab] = Number(button.dataset.portfolioItemIndex);
        renderCurrentPanel();
      });
    });
    portfolioPanel.querySelectorAll("[data-portfolio-image-index]").forEach((button) => {
      button.addEventListener("click", () => {
        const item = items[state.selected[state.tab]];
        updateGalleryImage(item, Number(button.dataset.portfolioImageIndex));
      });
    });
  };
  const renderCurrentPanel = () => {
    if (!portfolioPanel) return;
    portfolioPanel.classList.remove("is-switching");
    void portfolioPanel.offsetWidth;
    portfolioPanel.classList.add("is-switching");

    portfolioTabs.forEach((tab) => {
      const active = tab.dataset.portfolioTab === state.tab;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
    });

    const items = portfolioData[state.tab];
    const selectedIndex = state.selected[state.tab];
    const selectorLabel = state.tab === "solutions" ? "Soluciones ISM" : "Clientes ISM";
    const current = items[selectedIndex];
    portfolioPanel.innerHTML = renderWorkbench(items, selectedIndex, selectorLabel);
    portfolioPanel.setAttribute("aria-label", selectorLabel);
    if (portfolioStatus) portfolioStatus.textContent = `Mostrando ${current.name}.`;

    bindPanelInteractions();
    syncLucide();
  };

  portfolioTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      state.tab = tab.dataset.portfolioTab === "solutions" ? "solutions" : "clients";
      renderCurrentPanel();
    });
  });

  renderCurrentPanel();
}
const vaultSection = document.querySelector(".project-vault-section");
if (vaultSection) {
  const vaultTabs = vaultSection.querySelectorAll(".vault-tab");
  const vaultNodes = vaultSection.querySelectorAll(".vault-node");
  const vaultInspector = vaultSection.querySelector(".vault-inspector");
  const inspectorVisual = vaultSection.querySelector(".inspector-visual");
  const inspectorType = document.getElementById("vaultInspectorType");
  const inspectorName = document.getElementById("vaultInspectorName");
  const inspectorStatus = document.getElementById("vaultInspectorStatus");
  const inspectorTech = document.getElementById("vaultInspectorTech");
  const inspectorDescription = document.getElementById("vaultInspectorDescription");
  const inspectorStage = document.getElementById("vaultInspectorStage");
  const inspectorDate = document.getElementById("vaultInspectorDate");
  const inspectorLink = document.getElementById("vaultInspectorLink");
  const tabCounters = vaultSection.querySelectorAll("[data-vault-count]");
  const vaultTrack = vaultSection.querySelector(".vault-track");
  const prevArrow = vaultSection.querySelector(".vault-arrow-prev");
  const nextArrow = vaultSection.querySelector(".vault-arrow-next");
  const vaultIndex = vaultSection.querySelector(".vault-index");
  const getPreviewClass = (node) => {
    const preview = node.querySelector(".vault-preview");
    return [...preview.classList].find((className) => className.startsWith("preview-"));
  };
  const syncVaultIndex = (activeNode) => {
    if (!vaultIndex) return;
    vaultIndex.querySelectorAll(".vault-index-button").forEach((button) => {
      button.classList.toggle("active", button.dataset.vaultTarget === activeNode.dataset.name);
    });
  };
  const syncVaultStack = (activeNode) => {
    const visibleNodes = [...vaultNodes].filter((node) => !node.classList.contains("is-hidden"));
    const activeIndex = visibleNodes.indexOf(activeNode);
    const totalNodes = visibleNodes.length;
    visibleNodes.forEach((node, index) => {
      let offset = index - activeIndex;
      if (totalNodes > 1) {
        if (offset > totalNodes / 2) offset -= totalNodes;
        if (offset < -totalNodes / 2) offset += totalNodes;
      }
      const distance = Math.abs(offset);
      node.classList.toggle("is-before", offset < 0);
      node.classList.toggle("is-after", offset > 0);
      node.classList.toggle("is-stack-visible", distance <= 2);
      node.style.setProperty("--stack-distance", distance);
      node.style.setProperty("--stack-offset", offset);
    });
  };
  const setProjectData = (node) => {
    const preview = node.querySelector(".vault-preview");
    const previewClass = getPreviewClass(node);
    vaultNodes.forEach((item) => item.classList.remove("active"));
    node.classList.add("active");
    if (vaultInspector) {
      const nodeStyles = getComputedStyle(node);
      vaultInspector.style.setProperty("--project-accent", nodeStyles.getPropertyValue("--project-accent"));
      vaultInspector.style.setProperty("--project-glow", nodeStyles.getPropertyValue("--project-glow"));
      vaultInspector.classList.remove("is-switching");
      void vaultInspector.offsetWidth;
      vaultInspector.classList.add("is-switching");
    }
    if (inspectorVisual && preview) {
      inspectorVisual.className = `inspector-visual ${previewClass}`;
      inspectorVisual.innerHTML = preview.innerHTML;
    }
    inspectorType.textContent = node.dataset.type;
    inspectorName.textContent = node.dataset.name;
    inspectorStatus.textContent = node.dataset.status;
    inspectorTech.textContent = node.dataset.tech;
    inspectorDescription.textContent = node.dataset.description;
    inspectorStage.textContent = node.dataset.stage;
    inspectorDate.textContent = node.dataset.date;
    if (inspectorLink) {
      inspectorLink.hidden = false;
      inspectorLink.href = `portafolio.html?proyecto=${encodeURIComponent(node.dataset.projectId)}`;
      inspectorLink.textContent = node.dataset.caseStudy === "true" ? "Ver caso de estudio" : "Ver proyecto";
      inspectorLink.dataset.trackLabel = `${inspectorLink.textContent}: ${node.dataset.name}`;
      inspectorLink.dataset.projectId = node.dataset.projectId;
      inspectorLink.removeAttribute("target");
      inspectorLink.removeAttribute("rel");
    }
    const mobileDetail = node.querySelector(".vault-mobile-detail");
    if (mobileDetail) {
      mobileDetail.textContent = node.dataset.description;
    }
    syncVaultStack(node);
    syncVaultIndex(node);
  };
  const buildVaultIndex = (category) => {
    if (!vaultIndex) return;
    vaultIndex.innerHTML = "";
    [...vaultNodes]
      .filter((node) => node.dataset.category === category)
      .forEach((node, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "vault-index-button";
        button.dataset.vaultTarget = node.dataset.name;
        button.setAttribute("aria-label", node.dataset.name);
        button.innerHTML = "<span></span>";
        button.addEventListener("click", () => {
          setProjectData(node);
          scrollProjectIntoView(node);
        });
        vaultIndex.appendChild(button);
      });
  };
  const scrollProjectIntoView = (node) => {
    if (!vaultTrack || window.innerWidth > 760) return;
    node.scrollIntoView({
      behavior: "smooth",
      block: "nearest",
      inline: "start"
    });
  };
  const filterVault = (category, shouldScroll = false) => {
    let firstVisibleNode = null;
    vaultNodes.forEach((node) => {
      const isVisible = node.dataset.category === category;
      node.classList.toggle("is-hidden", !isVisible);
      node.classList.remove("is-before", "is-after");
      node.style.removeProperty("--stack-distance");
      node.style.removeProperty("--stack-offset");
      if (isVisible && !firstVisibleNode) {
        firstVisibleNode = node;
      }
    });
    if (firstVisibleNode) {
      const preferredNode = [...vaultNodes].find((node) => (
        node.dataset.category === category && node.dataset.caseStudy === "true"
      ));
      buildVaultIndex(category);
      setProjectData(preferredNode || firstVisibleNode);
      if (shouldScroll) {
        scrollProjectIntoView(preferredNode || firstVisibleNode);
      }
    }
  };
  tabCounters.forEach((counter) => {
    const category = counter.dataset.vaultCount;
    counter.textContent = [...vaultNodes].filter((node) => node.dataset.category === category).length;
  });
  vaultTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      vaultTabs.forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      filterVault(tab.dataset.vaultFilter, true);
    });
  });
  let vaultScrollTimer;
  vaultTrack?.addEventListener("scroll", () => {
    if (window.innerWidth > 760) return;
    clearTimeout(vaultScrollTimer);
    vaultScrollTimer = setTimeout(() => {
      const visibleNodes = [...vaultNodes].filter((node) => !node.classList.contains("is-hidden"));
      const trackRect = vaultTrack.getBoundingClientRect();
      const nearestNode = visibleNodes.reduce((nearest, node) => {
        const nodeRect = node.getBoundingClientRect();
        const distance = Math.abs(nodeRect.left - trackRect.left);
        if (!nearest || distance < nearest.distance) {
          return { node, distance };
        }
        return nearest;
      }, null);
      if (nearestNode?.node) {
        setProjectData(nearestNode.node);
      }
    }, 80);
  });
  vaultNodes.forEach((node) => {
    node.dataset.trackEvent = "project_click";
    node.dataset.trackCategory = "portfolio";
    node.dataset.trackLabel = node.dataset.name;
    if (node.dataset.projectId && !node.querySelector(".vault-mobile-action")) {
      const action = document.createElement("span");
      action.className = "vault-mobile-action";
      action.textContent = node.dataset.caseStudy === "true" ? "Ver caso de estudio" : "Ver proyecto";
      action.addEventListener("click", (event) => {
        event.stopPropagation();
        window.trackEvent("project_click", {
          event_category: "portfolio",
          event_label: action.textContent,
          project_id: node.dataset.projectId,
          section: "proyectos"
        });
        window.location.href = `portafolio.html?proyecto=${encodeURIComponent(node.dataset.projectId)}`;
      });
      node.appendChild(action);
    }
    node.addEventListener("focus", () => setProjectData(node));
    node.addEventListener("click", () => setProjectData(node));
    node.addEventListener("mousemove", (event) => {
      const rect = node.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 100;
      const y = ((event.clientY - rect.top) / rect.height) * 100;
      node.style.setProperty("--mx", `${x}%`);
      node.style.setProperty("--my", `${y}%`);
    });
  });
  const scrollVault = (direction) => {
    const visibleNodes = [...vaultNodes].filter((node) => !node.classList.contains("is-hidden"));
    const activeIndex = visibleNodes.findIndex((node) => node.classList.contains("active"));
    const nextIndex = (activeIndex + direction + visibleNodes.length) % visibleNodes.length;
    if (visibleNodes[nextIndex]) {
      setProjectData(visibleNodes[nextIndex]);
    }
  };
  prevArrow?.addEventListener("click", () => scrollVault(-1));
  nextArrow?.addEventListener("click", () => scrollVault(1));
  filterVault("presencias");
}
// FORMULARIO DE CONTACTO
// Arma una solicitud ordenada y la envía por WhatsApp.
const contactForm = document.getElementById("contactForm");
if (contactForm) {
  const serviceSelect = document.getElementById("contactServicio");
  const messageField = document.getElementById("contactMensaje");
  const productContext = document.getElementById("contactProductContext");
  const productContextTitle = document.getElementById("contactProductContextTitle");
  const productContextText = document.getElementById("contactProductContextText");

  const contactParams = new URLSearchParams(window.location.search);
  const requestedProductId = contactParams.get("producto");
  const requestedServiceId = contactParams.get("servicio");

  const productAliases = {
    "ism-stock-control": "ism-stock",
    "ism-gestion-control": "ism-control",
    "tool-service-hours": "ism-project",
    "tool-service-sizing": "ism-configurador",
    "tool-availability-agenda": "ism-reservas",
    "guia-web": "ism-asistente"
  };
  const normalizedRequestedProductId = productAliases[requestedProductId] || requestedProductId;

  const productNames = {
    "ism-presencia-digital": "ISM Presencia Digital",
    "ism-boutique": "ISM Boutique",
    "ism-reservas": "ISM Reservas",
    "ism-project": "ISM Project",
    "ism-control": "ISM Control",
    "ism-stock": "ISM Stock",
    "ism-configurador": "ISM Configurador",
    "ism-asistente": "ISM Asistente"
  };

  const productPrompts = {
    "ism-presencia-digital": "Cuéntanos qué necesita comunicar, captar o mejorar tu presencia digital.",
    "ism-boutique": "Cuéntanos qué productos quieres mostrar y cómo recibes hoy las consultas de tus clientes.",
    "ism-reservas": "Cuéntanos cómo coordinas hoy horarios, disponibilidad y reservas.",
    "ism-project": "Cuéntanos cómo registras hoy horas, actividades, clientes y proyectos.",
    "ism-control": "Cuéntanos qué procesos, responsables o módulos necesitas centralizar.",
    "ism-stock": "Cuéntanos cómo manejas hoy stock, bodegas, entregas o movimientos.",
    "ism-configurador": "Cuéntanos qué servicios, variables u opciones debería poder configurar tu cliente o equipo.",
    "ism-asistente": "Cuéntanos qué preguntas debería responder tu cliente y qué recomendación quieres entregar al final."
  };

  const productContextMessages = {
    "ism-presencia-digital": "Evaluaremos alcance, contenido, captación e integraciones necesarias para tu negocio.",
    "ism-boutique": "Evaluaremos catálogo, categorías, productos, administración y canal de contacto.",
    "ism-reservas": "Evaluaremos servicios, disponibilidad, reglas de agenda, reservas y posibles automatizaciones.",
    "ism-project": "Evaluaremos usuarios, clientes, proyectos, actividades, horas y reportes necesarios.",
    "ism-control": "Evaluaremos CORE administrativo, procesos, responsables, módulos e integraciones.",
    "ism-stock": "Evaluaremos bodegas, movimientos, roles, trazabilidad y necesidades de operación.",
    "ism-configurador": "Evaluaremos catálogo, reglas, variables, resumen y flujo de solicitud o precotización.",
    "ism-asistente": "Evaluaremos preguntas, decisiones, recomendaciones, captura de datos y siguiente paso comercial."
  };

  const serviceNames = {
    "desarrollo-implementacion": "Desarrollo e Implementación",
    "mantenimiento-evolucion": "Mantenimiento y Evolución",
    "monitoreo-observabilidad": "Monitoreo y Observabilidad",
    "respaldo-continuidad": "Respaldo y Continuidad Operacional",
    "ciberseguridad-proteccion": "Ciberseguridad y Protección Digital",
    "soporte-gestion": "Soporte y Gestión de Servicios"
  };

  if (normalizedRequestedProductId && productNames[normalizedRequestedProductId] && serviceSelect) {
    serviceSelect.value = productNames[normalizedRequestedProductId];

    if (messageField && !messageField.value) {
      messageField.placeholder = productPrompts[normalizedRequestedProductId];
    }

    if (productContext && productContextTitle && productContextText) {
      productContext.hidden = false;
      productContextTitle.textContent = productNames[normalizedRequestedProductId];
      productContextText.textContent = productContextMessages[normalizedRequestedProductId];
    }

    window.trackEvent?.("product_interest_prefilled", {
      event_category: "conversion",
      product_interest: normalizedRequestedProductId,
      section: "contacto"
    });
  } else if (requestedServiceId && serviceNames[requestedServiceId] && serviceSelect) {
    serviceSelect.value = serviceNames[requestedServiceId];
  }
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(contactForm);
    const nombre = formData.get("nombre")?.trim();
    const empresa = formData.get("empresa")?.trim() || "No indicado";
    const whatsapp = formData.get("whatsapp")?.trim();
    const servicio = formData.get("servicio")?.trim();
    const mensaje = formData.get("mensaje")?.trim() || "Quiero conversar mi idea con más detalle.";
    const whatsappText = [
      "Hola, Ignacio. Quiero conversar un proyecto con ISM Developer.",
      "",
      `Nombre: ${nombre}`,
      `Empresa o negocio: ${empresa}`,
      `WhatsApp: ${whatsapp}`,
      `Solución / servicio de interés: ${servicio}`,
      "",
      `Mensaje: ${mensaje}`
    ].join("\n");
    window.trackEvent("contact_form_submit", {
      event_category: "conversion",
      service_interest: servicio,
      product_interest: normalizedRequestedProductId || "",
      section: "contacto"
    });
    window.open(
      `https://wa.me/56968374821?text=${encodeURIComponent(whatsappText)}`,
      "_blank",
      "noopener,noreferrer"
    );
  });
}
// LUCIDE ICONS
// Convierte los <i data-lucide=""> en iconos SVG
if (window.lucide) {
  lucide.createIcons();
}
// FAQ / PREGUNTAS FRECUENTES
// Todas las respuestas comienzan cerradas. Solo una pregunta puede permanecer abierta.
const faqItems = [...document.querySelectorAll(".faq-item")];
const closeFaqItem = (item) => {
  const question = item.querySelector(".faq-question");
  const answer = item.querySelector(".faq-answer");
  if (!question || !answer) return;
  item.classList.remove("is-open");
  question.setAttribute("aria-expanded", "false");
  answer.setAttribute("aria-hidden", "true");
  answer.style.maxHeight = "0px";
};
faqItems.forEach((item, index) => {
  const question = item.querySelector(".faq-question");
  const answer = item.querySelector(".faq-answer");
  if (!question || !answer) return;
  const questionId = `faq-question-${index + 1}`;
  const answerId = `faq-answer-${index + 1}`;
  question.id = questionId;
  question.setAttribute("aria-controls", answerId);
  answer.id = answerId;
  answer.setAttribute("role", "region");
  answer.setAttribute("aria-labelledby", questionId);
  // Estado inicial explícito: evita aperturas causadas por otras clases o por el historial del navegador.
  closeFaqItem(item);
  question.addEventListener("click", () => {
    const shouldOpen = !item.classList.contains("is-open");
    faqItems.forEach(closeFaqItem);
    if (!shouldOpen) return;
    item.classList.add("is-open");
    question.setAttribute("aria-expanded", "true");
    answer.setAttribute("aria-hidden", "false");
    answer.style.maxHeight = `${answer.scrollHeight}px`;
  });
});
// CONFIGURADOR DE SERVICIOS
// Solo el CTA Configurar este servicio abre la confirmación.
const configuratorLinks = document.querySelectorAll("[data-configurator-link]");
const configuratorDialog = document.getElementById("serviceConfiguratorDialog");
const configuratorDescription = document.getElementById("serviceConfiguratorDescription");
const configuratorConfirm = configuratorDialog?.querySelector("[data-configurator-confirm]");
const configuratorCancel = configuratorDialog?.querySelector("[data-configurator-cancel]");
let configuratorOriginCard = null;
const closeConfiguratorDialog = () => {
  if (!configuratorDialog?.open) return;
  configuratorDialog.close();
  configuratorOriginCard?.focus();
  configuratorOriginCard = null;
};
configuratorLinks.forEach((card) => {
  card.addEventListener("click", (event) => {
    // Mantiene disponibles abrir en pestaña nueva y otros comportamientos nativos del enlace.
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || event.button !== 0) {
      return;
    }
    const destination = card.href;
    const serviceName = card.dataset.serviceName || "el servicio seleccionado";
    if (!configuratorDialog || typeof configuratorDialog.showModal !== "function") {
      const shouldContinue = window.confirm(
        `¿Quieres configurar tu servicio?\n\nServicio seleccionado: ${serviceName}`
      );
      if (!shouldContinue) {
        event.preventDefault();
      }
      return;
    }
    event.preventDefault();
    configuratorOriginCard = card;
    if (configuratorDescription) {
      configuratorDescription.textContent =
        `Abriremos una configuración guiada para “${serviceName}” y conservaremos esta selección.`;
    }
    if (configuratorConfirm) {
      configuratorConfirm.href = destination;
      configuratorConfirm.dataset.serviceName = serviceName;
    }
    configuratorDialog.showModal();
  });
});
configuratorCancel?.addEventListener("click", closeConfiguratorDialog);
configuratorConfirm?.addEventListener("click", () => {
  const serviceName = configuratorConfirm.dataset.serviceName || "Servicio no indicado";
  if (typeof window.trackEvent === "function") {
    window.trackEvent("service_configurator_confirm", {
      event_category: "conversion",
      service_name: serviceName,
      section: "servicios"
    });
  }
});
configuratorDialog?.addEventListener("click", (event) => {
  if (event.target === configuratorDialog) {
    closeConfiguratorDialog();
  }
});
configuratorDialog?.addEventListener("cancel", (event) => {
  event.preventDefault();
  closeConfiguratorDialog();
});
// SLIDER COLABORACIÓN ISM
// Carrusel simple con navegación manual y autoplay cada 5 segundos.
const collaborationSlider = document.querySelector('[data-collaboration-slider]');
if (collaborationSlider) {
  const slides = [...collaborationSlider.querySelectorAll('.collaboration-slide')];
  const dots = [...collaborationSlider.querySelectorAll('[data-collaboration-dot]')];
  const prevBtn = collaborationSlider.querySelector('[data-collaboration-prev]');
  const nextBtn = collaborationSlider.querySelector('[data-collaboration-next]');
  let activeIndex = slides.findIndex((slide) => slide.classList.contains('is-active'));
  let sliderTimer;
  if (activeIndex < 0) activeIndex = 0;
  const renderCollaborationSlide = (newIndex) => {
    const previousIndex = activeIndex;
    activeIndex = (newIndex + slides.length) % slides.length;
    slides.forEach((slide, index) => {
      const isActive = index === activeIndex;
      slide.classList.toggle('is-active', isActive);
      slide.classList.toggle('is-leaving-left', index === previousIndex && previousIndex !== activeIndex);
      slide.setAttribute('aria-hidden', String(!isActive));
    });
    dots.forEach((dot, index) => {
      const isActive = index === activeIndex;
      dot.classList.toggle('is-active', isActive);
      dot.setAttribute('aria-selected', String(isActive));
    });
  };
  const startCollaborationAutoplay = () => {
    clearInterval(sliderTimer);
    sliderTimer = setInterval(() => {
      renderCollaborationSlide(activeIndex + 1);
    }, 5000);
  };
  prevBtn?.addEventListener('click', () => {
    renderCollaborationSlide(activeIndex - 1);
    startCollaborationAutoplay();
  });
  nextBtn?.addEventListener('click', () => {
    renderCollaborationSlide(activeIndex + 1);
    startCollaborationAutoplay();
  });
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      renderCollaborationSlide(index);
      startCollaborationAutoplay();
    });
  });
  collaborationSlider.addEventListener('mouseenter', () => clearInterval(sliderTimer));
  collaborationSlider.addEventListener('mouseleave', startCollaborationAutoplay);
  collaborationSlider.addEventListener('focusin', () => clearInterval(sliderTimer));
  collaborationSlider.addEventListener('focusout', startCollaborationAutoplay);
  renderCollaborationSlide(activeIndex);
  startCollaborationAutoplay();
}
// STORY SLIDER | COLABORACIÓN ISM
// Sección completa con autoplay cada 8 segundos y navegación manual.
const storySlider = document.querySelector('[data-story-slider]');
if (storySlider) {
  const slides = [...storySlider.querySelectorAll('[data-story-slide]')];
  const dots = [...storySlider.querySelectorAll('[data-story-dot]')];
  const prevButton = storySlider.querySelector('[data-story-prev]');
  const nextButton = storySlider.querySelector('[data-story-next]');
  let currentStory = slides.findIndex((slide) => slide.classList.contains('is-active'));
  let storyTimer;
  if (currentStory < 0) currentStory = 0;
  const showStory = (index) => {
    currentStory = (index + slides.length) % slides.length;
    slides.forEach((slide, slideIndex) => {
      const isActive = slideIndex === currentStory;
      slide.classList.toggle('is-active', isActive);
      slide.setAttribute('aria-hidden', String(!isActive));
    });
    dots.forEach((dot, dotIndex) => {
      const isActive = dotIndex === currentStory;
      dot.classList.toggle('is-active', isActive);
      dot.setAttribute('aria-selected', String(isActive));
    });
  };
  const restartStoryAutoplay = () => {
    clearInterval(storyTimer);
    storyTimer = setInterval(() => {
      showStory(currentStory + 1);
    }, 8000);
  };
  prevButton?.addEventListener('click', () => {
    showStory(currentStory - 1);
    restartStoryAutoplay();
  });
  nextButton?.addEventListener('click', () => {
    showStory(currentStory + 1);
    restartStoryAutoplay();
  });
  dots.forEach((dot, dotIndex) => {
    dot.addEventListener('click', () => {
      showStory(dotIndex);
      restartStoryAutoplay();
    });
  });
  storySlider.addEventListener('mouseenter', () => clearInterval(storyTimer));
  storySlider.addEventListener('mouseleave', restartStoryAutoplay);
  storySlider.addEventListener('focusin', () => clearInterval(storyTimer));
  storySlider.addEventListener('focusout', restartStoryAutoplay);
  showStory(currentStory);
  restartStoryAutoplay();
}
