const projects = [
{
        id: "ism-presencia-digital",
        category: "Soluciones ISM",
        name: "ISM Presencia Digital",
        short: "Presencia profesional y captación",
        type: "Solución ISM / Presencia digital",
        status: "Disponible",
        accent: "#16bdf2",
        accentRgb: "22, 189, 242",
        url: null,
        summary: "Solución de entrada para empresas, profesionales y emprendimientos que necesitan una presencia web propia, clara y preparada para captar contactos y evolucionar junto al negocio.",
        metrics: [["Estado", "Disponible"], ["Tipo", "Solución ISM"], ["Enfoque", "Captación"], ["Nivel", "Inicial"]],
        stack: "Sitio web · Responsive · SEO inicial · Contacto",
        journey: [
            {
                title: "Una presencia profesional adaptada a cada rubro",
                description: "La base de ISM Presencia Digital se personaliza según marca, servicios, público y objetivos comerciales para entregar un canal propio y coherente.",
                focus: "Presencia",
                result: "Credibilidad",
                image: "assets/img/portfolio/proestakis-web-principal.webp",
                alt: "Ejemplo de implementación corporativa de ISM Presencia Digital"
            },
            {
                title: "Captación conectada con los canales del negocio",
                description: "WhatsApp, formularios, ubicación, redes sociales y llamados a la acción se integran en una experiencia orientada a facilitar el contacto.",
                focus: "Captación",
                result: "Contacto",
                image: "assets/img/portfolio/lecasse-principal.webp",
                alt: "Ejemplo tecnológico de implementación de ISM Presencia Digital"
            },
            {
                title: "Una base preparada para seguir creciendo",
                description: "La presencia puede conectarse después con reservas, catálogos, asistentes, configuradores u otras soluciones sin reconstruir todo desde cero.",
                focus: "Evolución",
                result: "Escalabilidad",
                image: "assets/img/portfolio/badia-nurse-shield-agenda.webp",
                alt: "Ejemplo de evolución con agenda conectada a una presencia digital"
            }
        ],
        analysis: ["Negocios sin una presencia digital profesional", "Dependencia exclusiva de redes sociales o mensajería", "Servicios difíciles de presentar con claridad", "Necesidad de una base propia preparada para crecer"],
        actionPlan: ["Sitio web responsive alineado con la marca", "Servicios, contacto, WhatsApp y redes sociales", "Mapa o ubicación y formulario básico", "SEO técnico inicial y publicación"],
        scalability: ["ISM Reservas", "ISM Boutique", "ISM Asistente", "ISM Configurador", "Integraciones y nuevas funciones"]
    },
{
        id: "ism-boutique",
        category: "Soluciones ISM",
        name: "ISM Boutique",
        short: "Catálogo digital de productos",
        type: "Solución ISM / Catálogo digital",
        status: "En desarrollo",
        accent: "#f9a8d4",
        accentRgb: "249, 168, 212",
        url: null,
        summary: "Catálogo web orientado a boutiques, accesorios, ropa, ferias y pequeños comercios que necesitan mostrar productos con identidad propia y generar contactos directos sin implementar todavía un e-commerce completo.",
        metrics: [["Estado", "En desarrollo"], ["Sector", "Comercio"], ["Foco", "Catálogo"], ["Canal", "WhatsApp"]],
        stack: "Catálogo · Categorías · Productos · WhatsApp · Administración",
        journey: [
            {
                title: "Una vitrina digital con identidad propia",
                description: "La solución organiza productos y categorías dentro de una presencia visual preparada para que el cliente pueda explorar la oferta desde celular o computador.",
                focus: "Catálogo",
                result: "Presentación",
                statusVisual: {
                    stage: "Producto en desarrollo",
                    label: "ISM Boutique",
                    detail: "Catálogo · categorías · productos · contacto directo"
                }
            },
            {
                title: "Contacto directo sin complejidad de e-commerce",
                description: "La versión Inicial prioriza fichas de producto, imágenes, precios y contacto por WhatsApp, sin pago online ni checkout obligatorio.",
                focus: "Conversión",
                result: "Contacto directo",
                image: "assets/img/portfolio/dimensionador-servicios-general.webp",
                alt: "Referencia visual de interfaz digital adaptable a ISM Boutique"
            }
        ],
        analysis: ["Productos mostrados solo en redes sociales", "Catálogos difíciles de ordenar o actualizar", "Clientes que necesitan consultar por WhatsApp", "Negocios que todavía no requieren un e-commerce completo"],
        actionPlan: ["Sitio de marca con catálogo y categorías", "Fichas de producto, imágenes y precios", "Contacto directo por WhatsApp", "Administración básica y carga inicial limitada", "Sin checkout ni pago online en la versión Inicial"],
        scalability: ["Más categorías y colecciones", "Integración con ISM Stock", "Promociones y productos destacados", "Pagos y checkout como evolución", "Analítica y automatizaciones comerciales"]
    },
{
        id: "ism-reservas",
        category: "Soluciones ISM",
        name: "ISM Reservas",
        short: "Agenda, disponibilidad y reservas",
        type: "Solución ISM / Agendamiento",
        status: "Disponible",
        accent: "#0ea5e9",
        accentRgb: "14, 165, 233",
        url: null,
        summary: "Solución para profesionales y negocios que necesitan publicar disponibilidad, recibir reservas online y administrar horarios sin depender de coordinación manual por mensajes o llamadas.",
        metrics: [["Estado", "Disponible"], ["Foco", "Reservas"], ["Unidad", "Cupos"], ["Gestión", "Agenda"]],
        stack: "Servicios · Agenda · Disponibilidad · Horarios · Reservas",
        journey: [
            {
                title: "Disponibilidad real antes de reservar",
                description: "La agenda presenta horarios y cupos disponibles para evitar cruces y facilitar que cada cliente encuentre una opción válida.",
                focus: "Disponibilidad",
                result: "Autonomía",
                image: "assets/img/portfolio/agenda-disponibilidad-dia-activo.webp",
                alt: "Agenda de ISM Reservas con un día activo y cupos disponibles"
            },
            {
                title: "Reglas que evitan reservas inexistentes",
                description: "Días cerrados, bloqueos y horarios configurados se respetan antes de ofrecer una hora, manteniendo consistencia entre lo publicado y la operación.",
                focus: "Agenda",
                result: "Orden",
                image: "assets/img/portfolio/agenda-disponibilidad-dia-cerrado.webp",
                alt: "Agenda de ISM Reservas con un día cerrado"
            }
        ],
        analysis: ["Coordinación manual de horas por WhatsApp o teléfono", "Cruces y reservas duplicadas", "Disponibilidad que cambia durante el mes", "Necesidad de recibir reservas fuera del horario de atención"],
        actionPlan: ["Servicios y horarios disponibles", "Reserva online con datos del cliente", "Panel administrativo de agenda", "Bloqueo y activación de horarios", "Gestión básica de reservas"],
        scalability: ["Múltiples profesionales", "Recordatorios automáticos", "Lista de espera", "Pagos y confirmaciones", "Integración con calendarios externos"]
    },
{
        id: "ism-project",
        category: "Soluciones ISM",
        name: "ISM Project",
        short: "Horas, clientes y proyectos",
        type: "Solución ISM / Gestión de proyectos",
        status: "Disponible",
        accent: "#2563eb",
        accentRgb: "37, 99, 235",
        url: null,
        summary: "Solución para registrar, consultar y reportar el trabajo realizado por clientes, proyectos, actividades y responsables, manteniendo trazabilidad de horas y ejecución.",
        metrics: [["Estado", "Disponible"], ["Foco", "Proyectos"], ["Unidad", "Horas"], ["Acceso", "Roles"]],
        stack: "Clientes · Proyectos · Actividades · Horas · Reportes",
        journey: [
            {
                title: "Acceso privado y responsabilidades definidas",
                description: "Los perfiles autorizados acceden a una operación separada por roles para mantener control sobre actividades, clientes y registros.",
                focus: "Acceso",
                result: "Control",
                image: "assets/img/portfolio/control-horas-login.webp",
                alt: "Pantalla de acceso privado de ISM Project"
            },
            {
                title: "Seguimiento de trabajo conectado con el cliente",
                description: "Horas, actividades, proyectos y oportunidades pueden consultarse desde una misma solución para respaldar gestión, reportes y valorización.",
                focus: "Gestión",
                result: "Trazabilidad",
                image: "assets/img/portfolio/control-horas-b2b.webp",
                alt: "Panel de seguimiento de ISM Project"
            }
        ],
        analysis: ["Horas registradas en planillas o fuentes separadas", "Dificultad para consultar actividad por cliente o proyecto", "Necesidad de respaldar gestión y cobro", "Reportes operativos armados manualmente"],
        actionPlan: ["Empresa, usuarios, clientes y proyectos", "Actividades y registro de horas", "Consulta histórica, filtros y reportes", "Exportación y panel administrativo", "Roles básicos en la versión Inicial"],
        scalability: ["Valorización y facturación", "Indicadores por cliente y proyecto", "Flujos de aprobación", "Integración con otros sistemas", "Automatizaciones y notificaciones"]
    },
{
        id: "ism-control",
        category: "Soluciones ISM",
        name: "ISM Control",
        short: "Administración modular de operaciones",
        type: "Solución ISM / Gestión modular",
        status: "En evolución",
        accent: "#34d399",
        accentRgb: "52, 211, 153",
        url: null,
        summary: "Plataforma administrativa modular que concentra un CORE común y permite incorporar procesos, responsables, recursos y módulos operativos según las necesidades de cada empresa.",
        metrics: [["Estado", "En evolución"], ["Tipo", "Plataforma"], ["Foco", "Operación"], ["Modelo", "Modular"]],
        stack: "CORE · Usuarios · Roles · Clientes · Proyectos · Módulos",
        journey: [
            {
                title: "Una base administrativa común",
                description: "Empresa, usuarios, roles, clientes y proyectos se concentran en un núcleo compartido para evitar información aislada entre procesos.",
                focus: "CORE",
                result: "Orden",
                image: "assets/img/project-ism-gestion-control-dashboard.svg",
                alt: "Vista conceptual del dashboard de ISM Control"
            },
            {
                title: "Módulos conectados a la misma operación",
                description: "La plataforma puede incorporar subsistemas específicos sin duplicar la administración principal ni perder trazabilidad entre responsables.",
                focus: "Módulos",
                result: "Integración",
                image: "assets/img/project-ism-gestion-control-inventario.svg",
                alt: "Vista conceptual de módulos en ISM Control"
            },
            {
                title: "Procesos preparados para evolucionar",
                description: "Nuevas unidades, permisos, flujos, reportes e integraciones pueden añadirse conforme aumenta la exigencia operativa del cliente.",
                focus: "Evolución",
                result: "Escalabilidad",
                image: "assets/img/project-ism-gestion-control-operaciones.svg",
                alt: "Vista conceptual de operaciones en ISM Control"
            }
        ],
        analysis: ["Procesos internos repartidos entre planillas y mensajes", "Falta de una administración común de usuarios y responsables", "Información difícil de auditar entre áreas", "Necesidad de crecer por módulos sin reconstruir el sistema"],
        actionPlan: ["CORE de empresa, usuarios, roles, clientes y proyectos", "Dashboard y estructura administrativa común", "Un módulo operativo inicial", "Bitácora, estados y trazabilidad", "Base para reportes e integraciones"],
        scalability: ["Nuevos módulos operativos", "Flujos de aprobación", "Alertas y automatizaciones", "Integraciones con otros sistemas", "Indicadores y reportería avanzada"]
    },
{
        id: "ism-stock",
        category: "Soluciones ISM",
        name: "ISM Stock",
        short: "Stock, bodegas y trazabilidad",
        type: "Solución ISM / Inventario y trazabilidad",
        status: "Producto activo",
        accent: "#22d3ee",
        accentRgb: "34, 211, 238",
        url: null,
        summary: "Solución para registrar existencias, entradas, salidas, entregas, retiros y movimientos de productos, insumos o herramientas con trazabilidad por usuario y operación.",
        metrics: [["Estado", "Producto activo"], ["Foco", "Stock"], ["Operación", "Bodegas"], ["Nivel", "Inicial"]],
        stack: "Stock · Bodegas · Movimientos · Roles · Trazabilidad",
        journey: [
            {
                title: "Inventario visible desde una operación central",
                description: "El panel permite revisar existencias, movimientos y estado general para reducir diferencias entre registros y stock físico.",
                focus: "Inventario",
                result: "Control",
                image: "assets/img/portfolio/control-bodega-admin.webp",
                alt: "Panel administrador de ISM Stock"
            },
            {
                title: "Movimientos registrados desde donde ocurren",
                description: "Recepciones, entregas, retiros y consultas pueden registrarse desde una interfaz preparada para la operación diaria y el uso móvil.",
                focus: "Operación",
                result: "Trazabilidad",
                image: "assets/img/portfolio/control-bodega-operativo.webp",
                alt: "Interfaz operativa móvil de ISM Stock"
            }
        ],
        analysis: ["Inventario distribuido entre planillas y registros manuales", "Diferencias entre stock físico y registros", "Falta de trazabilidad por responsable", "Necesidad de controlar bodegas, entregas y retiros"],
        actionPlan: ["Productos, categorías y stock", "Entradas, salidas, entregas y retiros", "Usuarios, roles e historial", "Importación inicial y exportación básica", "Dashboard operativo"],
        scalability: ["Nuevas bodegas y proyectos", "Alertas y automatizaciones", "Firma y evidencias", "Flujos de aprobación", "Integración con compras y abastecimiento"]
    },
{
        id: "ism-configurador",
        category: "Soluciones ISM",
        name: "ISM Configurador",
        short: "Alcance, opciones y precotización",
        type: "Solución ISM / Configuración comercial",
        status: "Disponible",
        accent: "#12bce7",
        accentRgb: "18, 188, 231",
        url: "configurador/",
        externalLabel: "Probar configurador",
        summary: "Herramienta adaptable para convertir servicios, actividades, cantidades y opciones en un alcance preliminar ordenado antes de preparar una cotización formal.",
        metrics: [["Estado", "Disponible"], ["Foco", "Configuración"], ["Salida", "Resumen"], ["Uso", "B2B"]],
        stack: "Servicios · Opciones · Reglas · HH · Resumen · Exportación",
        journey: [
            {
                title: "Configurar una necesidad desde opciones reales",
                description: "El usuario selecciona servicios, actividades y alternativas para construir un alcance preliminar sin comenzar desde una conversación o documento en blanco.",
                focus: "Configuración",
                result: "Orden",
                image: "assets/img/portfolio/dimensionador-servicios-general.webp",
                alt: "Vista principal de ISM Configurador"
            },
            {
                title: "Alcance visible mientras se decide",
                description: "Las reglas pueden mostrar cantidades, actividades, estimaciones, niveles o resúmenes para revisar el impacto de cada selección antes de cotizar.",
                focus: "Dimensionamiento",
                result: "Claridad",
                image: "assets/img/portfolio/dimensionador-servicios-detalle.webp",
                alt: "Detalle y resumen técnico de ISM Configurador"
            }
        ],
        analysis: ["Cotizaciones dependientes de levantamientos poco estandarizados", "Dificultad para explicar qué incluye cada servicio", "Riesgo de omitir actividades u opciones", "Necesidad de precalificar solicitudes antes de cotizar"],
        actionPlan: ["Catálogo configurable de servicios y alternativas", "Reglas, cantidades y dependencias", "Resumen consolidado de alcance", "Captura de datos del prospecto", "Exportación o envío para revisión comercial"],
        scalability: ["Plantillas por rubro", "Precios y tarifas", "Cotización comercial automática", "Integración con CRM", "Automatizaciones de seguimiento"]
    },
{
        id: "ism-asistente",
        category: "Soluciones ISM",
        name: "ISM Asistente",
        short: "Orientación y calificación guiada",
        type: "Solución ISM / Asistencia comercial",
        status: "Disponible",
        accent: "#8b5cf6",
        accentRgb: "139, 92, 246",
        url: "guia-web/",
        externalLabel: "Probar asistente",
        summary: "Asistente guiado y adaptable que realiza preguntas, ordena necesidades y conduce a cada prospecto hacia una recomendación o siguiente paso antes del contacto comercial.",
        metrics: [["Estado", "Disponible"], ["Foco", "Orientación"], ["Flujo", "Guiado"], ["Objetivo", "Conversión"]],
        stack: "Preguntas · Reglas · Recomendación · Captación · Seguimiento",
        journey: [
            {
                title: "Preguntas que ayudan a entender la necesidad",
                description: "El flujo guía al usuario paso a paso para identificar contexto, objetivo, situación actual y prioridades sin obligarlo a conocer términos técnicos.",
                focus: "Diagnóstico",
                result: "Claridad",
                image: "assets/img/guia-asistida-colaboracion.webp",
                alt: "Experiencia guiada de ISM Asistente"
            },
            {
                title: "Una recomendación antes del contacto comercial",
                description: "Las respuestas se convierten en una orientación estructurada que puede sugerir una solución, preparar el contacto o alimentar un proceso comercial posterior.",
                focus: "Recomendación",
                result: "Calificación",
                image: "assets/img/portfolio/dimensionador-servicios-detalle.webp",
                alt: "Referencia visual de resumen estructurado para ISM Asistente"
            }
        ],
        analysis: ["Prospectos que no saben qué servicio necesitan", "Consultas comerciales poco estructuradas", "Tiempo invertido en preguntas repetitivas", "Necesidad de calificar oportunidades antes de una reunión"],
        actionPlan: ["Flujo guiado de preguntas", "Reglas de decisión y recomendaciones", "Captura de datos del prospecto", "Siguiente paso personalizado", "Adaptación a servicios y lenguaje de cada empresa"],
        scalability: ["Integración con ISM Configurador", "Automatizaciones y CRM", "Rutas por segmento o rubro", "IA generativa cuando el alcance lo justifique", "Analítica de respuestas y conversión"]
    },
{
        id: "badiasalud",
        category: "Clientes ISM",
        name: "Badia Nurse Shield",
        short: "Sitio web + agenda",
        type: "Cliente ISM / ISM Presencia Digital",
        status: "Publicado",
        accent: "#16bdf2",
        accentRgb: "22, 189, 242",
        url: "https://www.badiasalud.cl",
        summary: "Javier, enfermero con más de 10 años de experiencia, nos pidió ayuda para gestionar un sistema de agenda con reservas que integrara su presencia digital y le permitiera automatizar la gestión de sus servicios.",
        metrics: [["Estado", "Publicado"], ["Sector", "Salud"], ["Canal", "Sitio + agenda"], ["Gestión", "Panel privado"]],
        stack: "Sitio web · Agenda · Procedimientos · Supabase",
        journey: [
            {
                title: "Una presencia profesional que genera confianza",
                description: "El sitio presenta los servicios, experiencia y propuesta de atención domiciliaria desde una identidad propia, con acceso directo a la reserva.",
                focus: "Sitio web",
                result: "Confianza",
                image: "assets/img/portfolio/badia-nurse-shield-sitio.webp",
                alt: "Sitio web de Badia Nurse Shield para atención de enfermería domiciliaria"
            },
            {
                title: "Disponibilidad visible y conectada",
                description: "La agenda privada organiza horarios, cupos y días disponibles sobre datos reales, evitando cruces y facilitando la administración diaria.",
                focus: "Agenda",
                result: "Orden operativo",
                image: "assets/img/portfolio/badia-nurse-shield-agenda.webp",
                alt: "Panel privado de agenda y disponibilidad de Badia Nurse Shield"
            },
            {
                title: "Servicios y reglas gestionados desde un panel",
                description: "Procedimientos, precios, configuración profesional y reglas operativas quedan centralizados para que la solución pueda evolucionar sin depender de cambios manuales en el sitio.",
                focus: "Gestión interna",
                result: "Autonomía",
                image: "assets/img/portfolio/badia-nurse-shield-panel.webp",
                alt: "Panel de procedimientos y configuración profesional de Badia Nurse Shield"
            }
        ],
        analysis: ["Presentar servicios y experiencia con una identidad propia", "Reducir coordinación manual de horas", "Mantener disponibilidad y solicitudes en un único sistema", "Permitir crecimiento del catálogo y operación"],
        actionPlan: ["Sitio web profesional responsive", "Agenda conectada a disponibilidad real", "Panel privado para procedimientos y configuración", "Flujo de solicitudes y lista de espera", "Base preparada para nuevas automatizaciones"],
        scalability: ["Recordatorios y confirmaciones automáticas", "Historial de pacientes y solicitudes", "Nuevas prestaciones y zonas de cobertura", "Administración de múltiples profesionales"]
    },
{
        id: "constructora-proestakis",
        category: "Clientes ISM",
        name: "Constructora Proestakis",
        short: "Presencia corporativa",
        type: "Cliente ISM / ISM Presencia Digital",
        status: "Publicado",
        accent: "#fb923c",
        accentRgb: "251, 146, 60",
        url: "https://constructora-proestakis.vercel.app/",
        summary: "Una vitrina digital para presentar experiencia, capacidad técnica y servicios desde un canal profesional propio orientado a nuevos clientes.",
        metrics: [["Estado", "Publicado"], ["Sector", "Construcción"], ["Enfoque", "Corporativo"], ["Experiencia", "Responsive"]],
        stack: "HTML5 · CSS3 · JavaScript · Vercel",
        journey: [
            {
                title: "La presencia corporativa en un entorno real",
                description: "La página principal se muestra dentro de un computador real para comunicar con claridad la marca, sus servicios y su propuesta desde el primer contacto.",
                focus: "Vista principal",
                result: "Credibilidad",
                image: "assets/img/portfolio/proestakis-web-principal.webp",
                alt: "Página principal de Constructora Proestakis mostrada en un computador"
            },
            {
                title: "Renovación presentada como experiencia visual",
                description: "La sección de renovación muestra trabajos antes y después dentro de una navegación real, facilitando la comprensión del resultado.",
                focus: "Renovación",
                result: "Evidencia",
                image: "assets/img/portfolio/proestakis-web-renovacion.webp",
                alt: "Sección de renovación de Constructora Proestakis mostrada durante una revisión en computador"
            },
            {
                title: "Servicios técnicos explicados en contexto",
                description: "La sección de electricidad industrial comunica alcance y capacidades técnicas mientras una persona navega el sitio desde un computador real.",
                focus: "Electricidad industrial",
                result: "Captación",
                image: "assets/img/portfolio/proestakis-web-electricidad.webp",
                alt: "Sección de electricidad industrial de Constructora Proestakis mostrada en un computador"
            }
        ],
        analysis: ["Falta de presencia digital consolidada", "Necesidad de respaldar experiencia y capacidades", "Mejorar la visibilidad de servicios", "Facilitar el contacto de nuevos clientes"],
        actionPlan: ["Sitio corporativo responsive", "Presentación de empresa y servicios", "Bloques de capacidad y experiencia", "Contacto directo y WhatsApp", "Base SEO inicial"],
        scalability: ["Portafolio ampliable de obras", "Formularios comerciales segmentados", "Agendamiento de visitas en terreno", "Módulos de seguimiento de proyectos"]
    },
{
        id: "lecasse-it-services",
        category: "Clientes ISM",
        name: "Lecasse IT Services",
        short: "Presencia tecnológica",
        type: "Cliente ISM / ISM Presencia Digital",
        status: "Publicado",
        accent: "#38bdf8",
        accentRgb: "56, 189, 248",
        url: "https://lecasse.vercel.app/",
        summary: "Una presencia tecnológica que ordena servicios y propuesta de valor para que potenciales clientes entiendan rápidamente las capacidades de la empresa.",
        metrics: [["Estado", "Publicado"], ["Sector", "Tecnología"], ["Modelo", "B2B"], ["Objetivo", "Captación"]],
        stack: "HTML5 · CSS3 · JavaScript · Vercel",
        journey: [
            {
                title: "Soluciones empresariales presentadas en contexto",
                description: "La propuesta tecnológica se muestra dentro de una reunión real, ayudando a visualizar cómo Lecasse comunica capacidades para plataformas empresariales y misión crítica.",
                focus: "Soluciones empresariales",
                result: "Claridad",
                image: "assets/img/portfolio/lecasse-reunion-soluciones.webp",
                alt: "Equipo revisando las soluciones de Lecasse en una sala de reuniones"
            },
            {
                title: "Desarrollo de software conectado con la operación",
                description: "La solución se presenta en un notebook dentro de una sala de servidores, reforzando la relación entre software, infraestructura y trabajo técnico en terreno.",
                focus: "Software en terreno",
                result: "Integración",
                image: "assets/img/portfolio/lecasse-servidores-software.webp",
                alt: "Dos profesionales revisando el desarrollo de software de Lecasse en una sala de servidores"
            },
            {
                title: "Infraestructura empresarial desde un entorno profesional",
                description: "La página se muestra en un notebook dentro de una oficina, destacando servicios de infraestructura, cloud, seguridad y continuidad operacional en un contexto corporativo real.",
                focus: "Infraestructura empresarial",
                result: "Confianza",
                image: "assets/img/portfolio/lecasse-oficina-infraestructura.webp",
                alt: "Sitio de infraestructura empresarial de Lecasse mostrado en un notebook dentro de una oficina"
            }
        ],
        analysis: ["Oferta tecnológica difícil de comunicar", "Necesidad de fortalecer confianza y posicionamiento", "Servicios B2B con alto componente técnico", "Pocos puntos de conversión comercial"],
        actionPlan: ["Sitio corporativo responsive", "Presentación clara de líneas de servicio", "Jerarquía orientada a problemas del cliente", "Puntos de contacto visibles", "Base preparada para casos y oportunidades"],
        scalability: ["Casos de estudio", "Contenido técnico", "Formularios comerciales segmentados", "Integración con CRM y módulos B2B"]
    }

];


const padSlideNumber = (value) => String(value).padStart(2, "0");

function escapeSvgText(value = "") {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function createMockSlideImage(project, index, headline, detail) {
    const slideNumber = padSlideNumber(index + 1);
    const svg = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" role="img" aria-label="${escapeSvgText(project.name)} ${slideNumber}">
            <defs>
                <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stop-color="#06101c"/>
                    <stop offset="45%" stop-color="#0a1a2b"/>
                    <stop offset="100%" stop-color="#03101a"/>
                </linearGradient>
                <radialGradient id="glowA" cx="0.2" cy="0.15" r="0.65">
                    <stop offset="0%" stop-color="rgba(22,189,242,0.34)"/>
                    <stop offset="100%" stop-color="rgba(22,189,242,0)"/>
                </radialGradient>
                <radialGradient id="glowB" cx="0.88" cy="0.84" r="0.7">
                    <stop offset="0%" stop-color="rgba(34,211,238,0.18)"/>
                    <stop offset="100%" stop-color="rgba(34,211,238,0)"/>
                </radialGradient>
            </defs>
            <rect width="1600" height="900" fill="url(#bg)"/>
            <rect width="1600" height="900" fill="url(#glowA)"/>
            <rect width="1600" height="900" fill="url(#glowB)"/>
            <rect x="74" y="74" width="1452" height="752" rx="36" fill="rgba(7,20,34,0.78)" stroke="rgba(22,189,242,0.25)" stroke-width="2"/>
            <rect x="108" y="108" width="1384" height="684" rx="28" fill="rgba(255,255,255,0.02)" stroke="rgba(255,255,255,0.08)" stroke-width="1.5"/>
            <text x="130" y="154" fill="#16bdf2" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="700" letter-spacing="6">ISM DEVELOPER</text>
            <text x="130" y="206" fill="#f5fbff" font-family="Arial, Helvetica, sans-serif" font-size="56" font-weight="700">${escapeSvgText(project.name)}</text>
            <text x="130" y="262" fill="#9fb2c8" font-family="Arial, Helvetica, sans-serif" font-size="28">${escapeSvgText(headline)}</text>
            <g transform="translate(130 334)">
                <rect width="300" height="74" rx="20" fill="rgba(22,189,242,0.10)" stroke="rgba(22,189,242,0.35)" stroke-width="1.5"/>
                <text x="150" y="46" text-anchor="middle" fill="#16bdf2" font-family="Arial, Helvetica, sans-serif" font-size="34" font-weight="700">Imagen de prueba ${slideNumber}</text>
            </g>
            <text x="130" y="472" fill="#d7e6f3" font-family="Arial, Helvetica, sans-serif" font-size="34" font-weight="700">Espacio listo para reemplazar con tu captura final.</text>
            <text x="130" y="526" fill="#a7bacd" font-family="Arial, Helvetica, sans-serif" font-size="27">${escapeSvgText(detail)}</text>
            <g transform="translate(130 616)">
                <rect width="260" height="60" rx="18" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.09)"/>
                <text x="130" y="38" text-anchor="middle" fill="#f5fbff" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="700">Mobile</text>
                <text x="130" y="53" text-anchor="middle" fill="#7fb3c8" font-family="Arial, Helvetica, sans-serif" font-size="13">experiencia multi-dispositivo</text>
            </g>
            <g transform="translate(418 616)">
                <rect width="260" height="60" rx="18" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.09)"/>
                <text x="130" y="38" text-anchor="middle" fill="#f5fbff" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="700">Versátil</text>
                <text x="130" y="53" text-anchor="middle" fill="#7fb3c8" font-family="Arial, Helvetica, sans-serif" font-size="13">adaptable a cada rubro</text>
            </g>
            <g transform="translate(706 616)">
                <rect width="260" height="60" rx="18" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.09)"/>
                <text x="130" y="38" text-anchor="middle" fill="#f5fbff" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="700">Intuitiva</text>
                <text x="130" y="53" text-anchor="middle" fill="#7fb3c8" font-family="Arial, Helvetica, sans-serif" font-size="13">flujo claro y fácil de usar</text>
            </g>
            <g transform="translate(994 616)">
                <rect width="260" height="60" rx="18" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.09)"/>
                <text x="130" y="38" text-anchor="middle" fill="#f5fbff" font-family="Arial, Helvetica, sans-serif" font-size="24" font-weight="700">Rápida</text>
                <text x="130" y="53" text-anchor="middle" fill="#7fb3c8" font-family="Arial, Helvetica, sans-serif" font-size="13">menos fricción, más acción</text>
            </g>
        </svg>`;

    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function createMockJourneySlide(project, index) {
    const slideNumber = padSlideNumber(index + 1);
    return {
        title: `Espacio visual ${slideNumber} listo para personalizar`,
        description: `Este espacio queda preparado con una imagen de prueba para que luego la reemplaces por una captura o fotografía final de ${project.name}.`,
        focus: `Imagen ${slideNumber}`,
        result: "Lista para reemplazo",
        image: createMockSlideImage(project, index, `Slide ${slideNumber} de apoyo visual`, `${project.short} · placeholder temporal para la versión 3.0.`),
        alt: `${project.name} · imagen de prueba ${slideNumber}`
    };
}

function normalizeJourney(project) {
    const normalizedJourney = project.journey.map((slide, index) => {
        if (slide.image) return slide;

        const headline = slide.statusVisual?.stage || slide.title || `Imagen ${padSlideNumber(index + 1)}`;
        const detail = slide.statusVisual?.detail || `${project.short} · espacio temporal para imagen de muestra.`;

        return {
            ...slide,
            image: createMockSlideImage(project, index, headline, detail),
            alt: slide.alt || `${project.name} · imagen de prueba ${padSlideNumber(index + 1)}`
        };
    });

    while (normalizedJourney.length < 3) {
        normalizedJourney.push(createMockJourneySlide(project, normalizedJourney.length));
    }

    return normalizedJourney;
}

projects.forEach((project) => {
    project.journey = normalizeJourney(project);
});


const commercialProfiles = {
    "ism-presencia-digital": {
        kicker: "Solución ISM",
        title: "Tu negocio profesionalmente en internet.",
        badge: "Entrada al ecosistema ISM",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Pymes, profesionales independientes, comercios y emprendimientos.",
            "Negocios que dependen principalmente de redes sociales o WhatsApp.",
            "Empresas que necesitan presentar servicios con mayor claridad y confianza.",
            "Proyectos que quieren una base digital propia preparada para evolucionar."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Sitio web responsive y presentación del negocio.",
            "Servicios, WhatsApp, redes sociales y contacto.",
            "Mapa o ubicación y formulario básico.",
            "SEO técnico inicial y publicación."
        ],
        pricing: { implementation: "$149.000", monthly: "$9.990 / mes", level: "Inicial" }
    },
    "ism-boutique": {
        kicker: "Solución ISM",
        title: "Tu catálogo digital, simple y profesional.",
        badge: "Catálogo + contacto directo",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Boutiques, accesorios, ropa y pequeños comercios.",
            "Emprendimientos que venden por Instagram, feria o WhatsApp.",
            "Negocios que necesitan ordenar y mostrar productos con identidad propia.",
            "Tiendas que aún no requieren un e-commerce completo."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Sitio de marca con catálogo y categorías.",
            "Fichas de producto, imágenes y precios.",
            "Contacto directo por WhatsApp.",
            "Administración básica y carga inicial limitada; sin checkout ni pago online."
        ],
        pricing: { implementation: "$199.000", monthly: "$14.990 / mes", level: "Inicial" }
    },
    "ism-reservas": {
        kicker: "Solución ISM",
        title: "Tus clientes reservan. Tú mantienes el control.",
        badge: "Agenda + disponibilidad",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Profesionales independientes y negocios que trabajan por hora.",
            "Salud, bienestar, estética, barberías y servicios técnicos.",
            "Equipos que coordinan reservas manualmente por mensajes o llamadas.",
            "Negocios que quieren recibir solicitudes incluso fuera del horario de atención."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Servicios, horarios y disponibilidad.",
            "Reserva online con datos del cliente.",
            "Panel administrativo de agenda.",
            "Bloqueo de horarios y gestión básica de reservas."
        ],
        pricing: { implementation: "$249.000", monthly: "$19.990 / mes", level: "Inicial" }
    },
    "ism-project": {
        kicker: "Solución ISM",
        title: "Horas y proyectos bajo control.",
        badge: "Gestión + trazabilidad",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Empresas de servicios, consultoras y equipos técnicos.",
            "Operaciones que necesitan registrar horas por cliente o proyecto.",
            "Equipos que requieren historial, filtros y reportes de ejecución.",
            "Empresas que necesitan respaldar gestión, valorización o cobro."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Empresa, usuarios, clientes y proyectos.",
            "Actividades y registro de horas.",
            "Consulta histórica, filtros y reportes.",
            "Exportación, panel administrativo y roles básicos."
        ],
        pricing: { implementation: "$299.000", monthly: "$24.990 / mes", level: "Inicial" }
    },
    "ism-control": {
        kicker: "Solución ISM",
        title: "Tu operación en un solo lugar.",
        badge: "CORE + módulo operativo",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Pymes y empresas con varios procesos administrativos u operativos.",
            "Equipos que necesitan centralizar usuarios, responsables y estados.",
            "Organizaciones que quieren incorporar módulos sin duplicar sistemas.",
            "Operaciones que requieren trazabilidad y crecimiento controlado."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "CORE de empresa, usuarios, roles, clientes y proyectos.",
            "Dashboard y estructura administrativa común.",
            "Un módulo operativo inicial.",
            "Base preparada para bitácora, reportes, automatizaciones e integraciones."
        ],
        pricing: { implementation: "$449.000", monthly: "$39.990 / mes", level: "Inicial" }
    },
    "ism-stock": {
        kicker: "Solución ISM",
        title: "Stock y trazabilidad bajo control.",
        badge: "Inventario + operación",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Bodegas, constructoras, contratistas y servicios técnicos.",
            "Empresas con productos, insumos o herramientas en movimiento.",
            "Operaciones que necesitan saber quién recibió, entregó o retiró recursos.",
            "Equipos que requieren historial confiable desde computador y celular."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Una empresa, un proyecto y una bodega principal como referencia base.",
            "Productos, categorías, stock, entradas y salidas.",
            "Entregas, retiros, trabajadores e historial.",
            "Roles, trazabilidad, importación inicial, exportación básica y dashboard."
        ],
        pricing: { implementation: "$549.000", monthly: "$49.990 / mes", level: "Inicial" }
    },
    "ism-configurador": {
        kicker: "Solución ISM",
        title: "Convierte necesidades en un alcance claro.",
        badge: "Configurable por rubro",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Empresas con servicios combinables, variables o difíciles de cotizar.",
            "Constructoras, consultoras, servicios técnicos y proveedores B2B.",
            "Equipos que necesitan estandarizar levantamientos y precotizaciones.",
            "Negocios que quieren que el cliente prepare su solicitud antes del contacto."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Catálogo configurable de servicios, actividades y opciones.",
            "Reglas, cantidades y dependencias según el proceso.",
            "Resumen estructurado del alcance solicitado.",
            "Captura de datos y salida para revisión comercial."
        ],
        pricing: { implementation: "$299.000", monthly: "$24.990 / mes", level: "Inicial" }
    },
    "ism-asistente": {
        kicker: "Solución ISM",
        title: "Guía a tus clientes hacia la solución correcta.",
        badge: "Orientación + calificación",
        audienceTitle: "Para quién está pensado",
        audience: [
            "Empresas que reciben consultas de clientes que no saben qué elegir.",
            "Negocios con preguntas comerciales repetitivas antes de cotizar.",
            "Equipos que quieren calificar prospectos antes de una reunión.",
            "Servicios que necesitan recomendar un siguiente paso según respuestas."
        ],
        capabilitiesTitle: "Qué incluye la versión Inicial",
        capabilities: [
            "Flujo guiado de preguntas adaptado al negocio.",
            "Reglas de decisión y recomendación.",
            "Captura de datos del prospecto.",
            "Siguiente paso personalizado y conexión con canales comerciales."
        ],
        pricing: { implementation: "$249.000", monthly: "$19.990 / mes", level: "Inicial" }
    }
};

const caseProductRelations = {
    "badiasalud": {
        productId: "ism-presencia-digital",
        productName: "ISM Presencia Digital",
        title: "Una implementación real de ISM Presencia Digital.",
        adapted: ["Identidad y propuesta de servicios", "Agenda y disponibilidad", "Panel privado de gestión", "Experiencia orientada a pacientes"],
        proves: ["La presencia digital puede evolucionar a sistema", "Una misma base puede incorporar agenda", "La solución se adapta a un profesional independiente"]
    },
    "constructora-proestakis": {
        productId: "ism-presencia-digital",
        productName: "ISM Presencia Digital",
        title: "Una implementación corporativa de ISM Presencia Digital.",
        adapted: ["Identidad corporativa", "Servicios y capacidad técnica", "Portafolio visual", "Contacto comercial"],
        proves: ["El producto funciona en servicios técnicos", "Puede comunicar experiencia y confianza", "La estructura se adapta a venta B2B"]
    },
    "lecasse-it-services": {
        productId: "ism-presencia-digital",
        productName: "ISM Presencia Digital",
        title: "Una implementación tecnológica de ISM Presencia Digital.",
        adapted: ["Servicios tecnológicos", "Propuesta B2B", "Arquitectura de contenido", "Contacto y posicionamiento"],
        proves: ["La base se adapta a una oferta técnica", "Permite ordenar servicios complejos", "Mantiene una identidad propia por cliente"]
    }
};

const categoryOrder = ["Soluciones ISM", "Clientes ISM"];
const categoryIcons = {
    "Soluciones ISM": "boxes",
    "Clientes ISM": "users-round"
};
const primarySolutionIds = new Set([
    "ism-presencia-digital",
    "ism-boutique",
    "ism-reservas",
    "ism-project",
    "ism-control",
    "ism-stock",
    "ism-configurador",
    "ism-asistente"
]);
const projectNav = document.getElementById("projectNav");
const visualTrack = document.getElementById("visualTrack");
const copyTrack = document.getElementById("copyTrack");
const sliderDots = document.getElementById("sliderDots");
const progressLine = document.getElementById("progressLine");
const currentSlideLabel = document.getElementById("currentSlide");
const totalSlidesLabel = document.getElementById("totalSlides");
const syncedSlider = document.getElementById("syncedSlider");
const routeLoader = document.getElementById("routeLoader");
const projectAliases = {
    "ism-stock-control": "ism-stock",
    "tool-warehouse-control": "ism-stock",
    "control-gestion": "ism-stock",
    "ism-gestion-control": "ism-control",
    "tool-service-hours": "ism-project",
    "tool-service-sizing": "ism-configurador",
    "tool-availability-agenda": "ism-reservas",
    "guia-web": "ism-asistente"
};
const rawRequestedProject = new URLSearchParams(window.location.search).get("proyecto");
let requestedProject = projectAliases[rawRequestedProject] || rawRequestedProject;

const visiblePortfolioProjects = projects.filter((project) =>
    project.category === "Clientes ISM" || primarySolutionIds.has(project.id)
);
const defaultProjectId = "ism-presencia-digital";

if (!visiblePortfolioProjects.some((project) => project.id === requestedProject)) {
    requestedProject = defaultProjectId;
}
let currentProject = null;
let currentSlide = 0;
let pointerStartX = null;

const pad = (value) => String(value).padStart(2, "0");

function renderNavigation() {
    const requestedCategory = projects.find((project) => project.id === requestedProject)?.category || categoryOrder[0];

    projectNav.innerHTML = categoryOrder.map((category) => {
        const items = visiblePortfolioProjects.filter((project) => project.category === category);
        const categoryId = `category-${category.toLowerCase().replace(/\s+/g, "-")}`;
        const expanded = category === requestedCategory;
        return `
            <div class="nav-group${expanded ? " expanded" : ""}" data-category-group="${category}">
                <button class="nav-group-toggle" type="button" aria-expanded="${expanded}" aria-controls="${categoryId}" title="${category}">
                    <i class="nav-group-icon" data-lucide="${categoryIcons[category]}"></i>
                    <span>${category}</span>
                    <span class="nav-group-count">${items.length}</span>
                </button>
                <div class="nav-group-items" id="${categoryId}">
                    ${items.map((project) => {
                        return `
                            <button class="project-nav-item" type="button" data-project="${project.id}">
                                <span class="nav-dot" aria-hidden="true"></span>
                                <span class="nav-copy"><strong>${project.name}</strong><small>${project.short}</small></span>
                            </button>`;
                    }).join("")}
                </div>
            </div>`;
    }).join("");

    projectNav.querySelectorAll(".nav-group-toggle").forEach((toggle) => {
        toggle.addEventListener("click", () => {
            const group = toggle.closest(".nav-group");
            if (document.body.classList.contains("sidebar-collapsed")) {
                document.body.classList.remove("sidebar-collapsed");
                group.classList.add("expanded");
                toggle.setAttribute("aria-expanded", "true");
                return;
            }
            const expanded = !group.classList.contains("expanded");
            group.classList.toggle("expanded", expanded);
            toggle.setAttribute("aria-expanded", String(expanded));
        });
    });

    projectNav.querySelectorAll("[data-project]").forEach((button) => {
        button.addEventListener("click", () => selectProject(button.dataset.project));
    });
}

function renderMetrics(project) {
    document.getElementById("projectMetrics").innerHTML = project.metrics.map(([label, value]) => `
        <div class="metric"><span>${label}</span><strong>${value}</strong></div>
    `).join("");
}

function renderSlides(project) {
    visualTrack.innerHTML = project.journey.map((slide, index) => {
        const visual = slide.image
            ? `<img src="${slide.image}" alt="${slide.alt}" loading="${index ? "lazy" : "eager"}" decoding="async">`
            : `<div class="project-status-visual" role="img" aria-label="${slide.statusVisual.label}: ${slide.statusVisual.stage}">
                    <span>${slide.statusVisual.stage}</span>
                    <strong>${slide.statusVisual.label}</strong>
                    <small>${slide.statusVisual.detail}</small>
               </div>`;

        return `
            <article class="visual-slide">
                <div class="screen-frame">
                    ${visual}
                    <span class="screen-badge">${slide.focus}</span>
                </div>
            </article>`;
    }).join("");

    copyTrack.innerHTML = project.journey.map((slide) => `
        <article class="copy-slide">
            <h3>${slide.title}</h3>
            <p>${slide.description}</p>
            <div class="copy-detail">
                <div><span>Foco</span><strong>${slide.focus}</strong></div>
                <div><span>Resultado</span><strong>${slide.result}</strong></div>
            </div>
        </article>
    `).join("");

    sliderDots.innerHTML = project.journey.map((slide, index) => `
        <button class="slider-dot" type="button" data-slide="${index}" aria-label="Ver ${slide.title}"></button>
    `).join("");

    sliderDots.querySelectorAll("[data-slide]").forEach((button) => {
        button.addEventListener("click", () => setSlide(Number(button.dataset.slide)));
    });

    totalSlidesLabel.textContent = pad(project.journey.length);
}

function renderTechnical(project) {
    const relation = caseProductRelations[project.id];
    const cards = relation
        ? [
            ["search-check", "Punto de partida", "Necesidades concretas que justificaron la implementación.", project.analysis],
            ["badge-check", "Solución implementada", "Elementos entregados para responder al contexto del cliente.", project.actionPlan],
            ["waypoints", "Evolución posible", "Capacidades que pueden incorporarse sobre la misma base.", project.scalability]
        ]
        : [
            ["search-check", "Necesidad que aborda", "Situaciones donde esta herramienta puede aportar orden o trazabilidad.", project.analysis],
            ["list-checks", "Qué resuelve", "Funciones principales incluidas en el alcance actual.", project.actionPlan],
            ["chart-no-axes-combined", "Cómo puede crecer", "Evoluciones posibles sobre la misma herramienta.", project.scalability]
        ];

    document.getElementById("technicalGrid").innerHTML = cards.map(([icon, title, description, items]) => `
        <article class="technical-card">
            <span class="tech-icon"><i data-lucide="${icon}"></i></span>
            <h3>${title}</h3>
            <p>${description}</p>
            <ul>${items.map((item) => `<li>${item}</li>`).join("")}</ul>
        </article>
    `).join("");
}


function renderCommercial(project) {
    const section = document.getElementById("commercialSection");
    if (!section) return;

    const profile = commercialProfiles[project.id];
    const relation = caseProductRelations[project.id];
    const audienceTitle = document.getElementById("commercialAudienceTitle");
    const capabilitiesTitle = document.getElementById("commercialCapabilitiesTitle");

    section.classList.toggle("is-product-profile", Boolean(profile));
    section.classList.toggle("is-case-profile", Boolean(relation));
    section.classList.toggle("is-tool-profile", ["ism-configurador", "ism-asistente"].includes(project.id));

    let view;
    let solutionId = null;

    if (profile) {
        view = profile;
        solutionId = project.id;
    } else if (relation) {
        view = {
            kicker: "Cliente ISM",
            title: relation.title,
            badge: `Implementación de ${relation.productName}`,
            audienceTitle: "Qué se adaptó al cliente",
            audience: relation.adapted,
            capabilitiesTitle: "Qué demuestra esta implementación",
            capabilities: relation.proves
        };
        solutionId = relation.productId;
    } else {
        view = {
            kicker: "Portafolio ISM",
            title: "Una herramienta creada para ordenar una tarea concreta.",
            badge: "Herramienta complementaria",
            audienceTitle: "Cuándo puede ser útil",
            audience: project.analysis.slice(0, 4),
            capabilitiesTitle: "Qué resuelve",
            capabilities: project.actionPlan.slice(0, 4)
        };
    }

    document.getElementById("commercialKicker").textContent = view.kicker;
    document.getElementById("commercialTitle").textContent = view.title;
    document.getElementById("commercialBadge").textContent = view.badge;
    audienceTitle.textContent = view.audienceTitle;
    capabilitiesTitle.textContent = view.capabilitiesTitle;
    document.getElementById("commercialAudience").innerHTML = view.audience.map((item) => `<li>${item}</li>`).join("");
    document.getElementById("commercialCapabilities").innerHTML = view.capabilities.map((item) => `<li>${item}</li>`).join("");

    const pricing = document.getElementById("commercialPricing");
    if (pricing) {
        const showPricing = Boolean(profile?.pricing);
        pricing.hidden = !showPricing;
        if (showPricing) {
            document.getElementById("commercialPriceImplementation").textContent = `Desde ${profile.pricing.implementation}`;
            document.getElementById("commercialPriceMonthly").textContent = `Desde ${profile.pricing.monthly}`;
            document.getElementById("commercialPriceLevel").textContent = profile.pricing.level;
        }
    }

    const actionEyebrow = document.getElementById("portfolioActionEyebrow");
    const actionTitle = document.getElementById("portfolioActionTitle");
    const actionDescription = document.getElementById("portfolioActionDescription");
    const whatsapp = document.getElementById("portfolioActionWhatsapp");
    const configurator = document.getElementById("portfolioActionConfigurator");
    const assistant = document.getElementById("portfolioActionAssistant");
    const form = document.getElementById("portfolioActionForm");

    const referenceName = profile ? project.name : relation ? relation.productName : project.name;

    if (profile) {
        actionEyebrow.textContent = "¿Quieres esta solución para tu empresa?";
        actionTitle.textContent = `Revisa ${project.name} según tu necesidad.`;
        actionDescription.textContent = "Elige la forma más cómoda de evaluar alcance, resolver dudas o solicitar una propuesta.";
    } else if (relation) {
        actionEyebrow.textContent = "¿Quieres una solución similar para tu empresa?";
        actionTitle.textContent = `Podemos adaptar ${relation.productName} a tu contexto.`;
        actionDescription.textContent = "Usa uno de estos canales para revisar tu necesidad sin recorrer más páginas.";
    } else {
        actionEyebrow.textContent = "¿Quieres evaluar esta herramienta?";
        actionTitle.textContent = "Revisemos si encaja en tu operación.";
        actionDescription.textContent = "Puedes conversar directo o definir primero el alcance con una herramienta ISM.";
    }

    const productQuery = solutionId ? `?producto=${encodeURIComponent(solutionId)}` : "";
    configurator.href = `configurador/${productQuery}`;
    assistant.href = "guia-web/";
    form.href = solutionId
        ? `index.html?producto=${encodeURIComponent(solutionId)}#contacto`
        : "index.html#contacto";

    whatsapp.href = `https://wa.me/56968374821?text=${encodeURIComponent(`Hola, quiero revisar ${referenceName} para mi empresa.`)}`;
}
function selectProject(id, options = {}) {
    const project = visiblePortfolioProjects.find((item) => item.id === id) || visiblePortfolioProjects[0];
    currentProject = project;
    currentSlide = 0;

    document.documentElement.style.setProperty("--accent", project.accent);
    document.documentElement.style.setProperty("--accent-rgb", project.accentRgb);
    document.title = `${project.name} | Portafolio ISM | ISM Developer`;
    document.getElementById("projectType").textContent = project.type;
    document.getElementById("projectTitle").textContent = project.name;
    document.getElementById("projectSummary").textContent = project.summary;
    document.getElementById("techStack").textContent = project.stack;

    const externalLink = document.getElementById("externalProjectLink");
    const externalLinkLabel = document.getElementById("externalProjectLinkLabel");
    const primaryLink = project.url;

    externalLink.hidden = !primaryLink;
    if (primaryLink) {
        externalLink.href = primaryLink;
        externalLinkLabel.textContent = project.externalLabel || "Visitar proyecto";
        const isExternal = /^https?:\/\//i.test(primaryLink);
        externalLink.target = isExternal ? "_blank" : "_self";
        externalLink.rel = isExternal ? "noopener noreferrer" : "";
    }

    projectNav.querySelectorAll("[data-project]").forEach((button) => {
        const isActive = button.dataset.project === project.id;
        button.classList.toggle("active", isActive);
        button.setAttribute("aria-current", isActive ? "true" : "false");

        if (isActive) {
            const group = button.closest(".nav-group");
            group?.classList.add("expanded");
            group?.querySelector(".nav-group-toggle")?.setAttribute("aria-expanded", "true");
        }
    });

    renderMetrics(project);
    renderSlides(project);
    renderTechnical(project);
    renderCommercial(project);
    setSlide(0);

    const url = new URL(window.location.href);
    url.searchParams.set("proyecto", project.id);
    window.history.replaceState({ project: project.id }, "", url);
    document.body.classList.remove("sidebar-open");

    if (window.lucide) window.lucide.createIcons();
    if (!options.initial && window.innerWidth > 820) {
        window.scrollTo({ top: 0, behavior: "smooth" });
    }
}

function setSlide(index) {
    if (!currentProject) return;
    const total = currentProject.journey.length;
    currentSlide = (index + total) % total;
    const translate = `translateX(-${currentSlide * 100}%)`;
    visualTrack.style.transform = translate;
    copyTrack.style.transform = translate;
    currentSlideLabel.textContent = pad(currentSlide + 1);
    progressLine.style.width = `${((currentSlide + 1) / total) * 100}%`;

    sliderDots.querySelectorAll(".slider-dot").forEach((dot, dotIndex) => {
        const active = dotIndex === currentSlide;
        dot.classList.toggle("active", active);
        dot.setAttribute("aria-current", active ? "true" : "false");
    });
}

document.getElementById("slidePrev").addEventListener("click", () => setSlide(currentSlide - 1));
document.getElementById("slideNext").addEventListener("click", () => setSlide(currentSlide + 1));

syncedSlider.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") setSlide(currentSlide - 1);
    if (event.key === "ArrowRight") setSlide(currentSlide + 1);
});

syncedSlider.addEventListener("pointerdown", (event) => {
    pointerStartX = event.clientX;
    syncedSlider.setPointerCapture?.(event.pointerId);
});

syncedSlider.addEventListener("pointerup", (event) => {
    if (pointerStartX === null) return;
    const delta = event.clientX - pointerStartX;
    pointerStartX = null;
    if (Math.abs(delta) > 48) setSlide(currentSlide + (delta < 0 ? 1 : -1));
});

const openSidebar = () => {
    document.body.classList.remove("sidebar-collapsed");
    if (window.innerWidth <= 820) document.body.classList.add("sidebar-open");
};
const closeSidebar = () => document.body.classList.remove("sidebar-open");
const collapseSidebar = () => {
    document.body.classList.remove("sidebar-open");
    if (window.innerWidth > 820) document.body.classList.toggle("sidebar-collapsed");
};
document.getElementById("sidebarToggle").addEventListener("click", openSidebar);
document.getElementById("sidebarClose").addEventListener("click", closeSidebar);
document.getElementById("sidebarCollapse").addEventListener("click", collapseSidebar);
document.getElementById("sidebarBackdrop").addEventListener("click", closeSidebar);

function updateClock() {
    document.getElementById("dashboardClock").textContent = new Intl.DateTimeFormat("es-CL", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).format(new Date());
}

renderNavigation();
const portfolioProjectCount = document.getElementById("portfolioProjectCount");
if (portfolioProjectCount) {
    const solutionCount = visiblePortfolioProjects.filter((project) => project.category === "Soluciones ISM").length;
    const clientCount = visiblePortfolioProjects.filter((project) => project.category === "Clientes ISM").length;
    portfolioProjectCount.textContent = `${solutionCount} soluciones · ${clientCount} clientes`;
}
selectProject(requestedProject, { initial: true });
updateClock();
setInterval(updateClock, 30000);

requestAnimationFrame(() => {
    routeLoader.classList.remove("visible");
    if (window.lucide) window.lucide.createIcons();
});
